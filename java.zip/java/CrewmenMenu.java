package src.main.java;

import java.util.ArrayList;
import src.main.java.Player.*;

public class CrewmenMenu{

	ArrayList<Crewmen> AvailableCrewmen = new ArrayList<Crewmen>();

	private void generateCrew(){
		//Crewmen potentialCrewmate1 = new Crewmen();
		
		for(int i = 0; i < 6; i++){
			AvailableCrewmen.add(new Crewmen());
		}
	}
	
	public void displayAvailableCrew(){
		generateCrew();
	
		for(int i = 0; i < 6; i++){
			AvailableCrewmen.get(i).displayCrewmenInformation();
			System.out.println();
		}
		Abstract.PressAnyKey();
	
		//System.out.println(AvailableCrewmen.get(displayCrewmenInformation() ));
	
	}

}