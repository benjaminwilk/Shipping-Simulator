package src.main.java;

import src.main.java.Player.*;
import java.util.ArrayList;

public class UserShipMates{
	private ArrayList<Crewmen> Shipmates = new ArrayList<Crewmen>();

	public void addShipmate(Crewmen passedCrewmen){
		Shipmates.add(passedCrewmen);
	}
	
	public void collectEngineeringLevel(){
		int EngineeringLevel = 0;
		for(int i = 0; i < Shipmates.size(); i++){
			EngineeringLevel += Shipmates.get(i).getEngineering();
		}
	}
	
	public void collectSteeringLevel(){
		int SteeringLevel = 0;
		for(int i = 0; i < Shipmates.size(); i++){
			SteeringLevel += Shipmates.get(i).getSteering();
		}
	}
	
	public void collectDefenseLevel(){
		int DefenseLevel = 0;
		for(int i = 0; i < Shipmates.size(); i++){
			DefenseLevel += Shipmates.get(i).getDefense();
		}
	}
	
	public void collectLoadingLevel(){
		int LoadingLevel = 0;
		for(int i = 0; i < Shipmates.size(); i++){
			LoadingLevel += Shipmates.get(i).getLoading();
		}
	}
	
	public void collectSalaryValue(){
		int Salary = 0;
		for(int i = 0; i < Shipmates.size(); i++){
			Salary += Shipmates.get(i).getSalary();
		}
	}
	
	public int getCrewCount(){
		return Shipmates.size();
	}
	
}