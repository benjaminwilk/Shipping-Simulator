package main.java.Graphics;

public class ShipGraphics{

  public static void tugboat(){
    System.out.println("                   ______ ");
    System.out.println("               ___/|_|_|/");
    System.out.println("              /         |_");
    System.out.println("     ________/            |____");
    System.out.println("   /\\                o   o     |_____");
    System.out.println("  |  -------------                  /");
    System.out.println("   \\                              / `~");
    System.out.println("     ----------------------------- `~`~`~`");
    System.out.println("                      `~`~`~``~`~`~`");
    System.out.println();
  }

  public static void dredge(){
    System.out.println("");
    System.out.println("                           8HHHHH8");
    System.out.println("                         /=/XXXX/ ");
    System.out.println("                        /X/====/ ");
    System.out.println("       ________________/=/XXXX/_");
    System.out.println("      |\\              /X/====/ \\");
    System.out.println("      | \\            /=/ XX /   \\");
    System.out.println("      |  \\__________/X/====/_____\\");
    System.out.println("   \\ \\   |    _    /=/XXXX/      |");
    System.out.println("   |\\ \\  |   |o|  | /    /       |");
    System.out.println("   \\ \\ \\|___|_|__|/____/|_______|");
    System.out.println("    \\ \\                          \\");
    System.out.println("     \\ \\          _______         \\");
    System.out.println("      \\ \\        \\     |\\        \\");
    System.out.println("       \\ \\        \\  `~| \\        \\");
    System.out.println("        \\ \\        \\ ~`~  \\        \\");
    System.out.println("         \\ \\________\\   `~ \\________\\");
    System.out.println("          \\ |         |   ~`  |         | ");
    System.out.println("       `~`~\\|         |    `~ |         | ");
    System.out.println("         `~`~`~    `~`~`~  `~`~`~    `~`~`~");
  }

  public static void smallFreighter(){

  }

  public static void shipBridge(){
    System.out.println("   _________________________________________________");
    System.out.println("  |   _________________________________      __     |\\");
    System.out.println("  |   |\\__                          __/|    |__|    |");
    System.out.println("  |   | |                            | |     PWR    |");
    System.out.println("  |   |                                |            |");
    System.out.println("  |   |                                |    ( )     |");
    System.out.println("  |   |                                |            |");
    System.out.println("  |   |                                |            |");
    System.out.println("  |   |                                |            |");
    System.out.println("  |   |                                |    ( )     |");
    System.out.println("  |   | |_                          _| |            |");
    System.out.println("  |   |/______________________________\\|            |");
    System.out.println("  |              World GPS                          |");
    System.out.println("  |_________________________________________________|\\");
    System.out.println("   \\");

  }











}
