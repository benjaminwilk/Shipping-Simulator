package main.java.Depricated;/*package src.main.java;

import src.main.java.Player.*;

public class PortData{

	private final static int maximumAmountOfContainersInPort = 1000;
	private final static int maximumContainerPriceInPort = 500;
	private final static int maximumPriceForFuelInPort = 500;
	
	private int portParse;

	// Name --> Short Name --> Longitude --> Latitude --> Amount of containers --> Price per container --> Oil Price
	private String[] shortNames = {"LB", "SY", "HK"};
	private String[] LongBeach = {"Long Beach", "LB", "33.754185", "-118.216458", "0", "0", "0"};
	private String[] Sydney = {"Sydney", "SY","-33.858333", "151.233333", "0", "0", "0"};
	private String[] HongKong = {"Hong Kong", "HK", "22.287753", "114.173619", "0", "0", "0"};
	//private final static String[] LongBeach = {};
	
	/*
	* 0 --> LB
	* 1 --> SY
	* 2 --> HK
	*/
	
/*public PortData(){
		generateData(LongBeach);	
		generateData(Sydney);
		generateData(HongKong);
	}
	
	public void generateData(String[] passedPort){
		passedPort[4] = "" + Abstract.getRandomValue(maximumAmountOfContainersInPort, 0);
		passedPort[5] = "" + Abstract.getRandomValue(maximumContainerPriceInPort, 0);
		passedPort[6] = "" + Abstract.getRandomValue(maximumPriceForFuelInPort, 0);
	}*/
	
/*	public parseLocations(int passedValue){
		String limboShortName = shortNames[passedValue];
		for(int i = 0; i < )if(limboShortName)
	}
	
	public parseLocations(String passedShortName){
		for(int i = 0; i < shortNames.length; i++){
			if(passedShortName.contains(shortNames[i])){
				
	}*/
	
/*	public void getData(){
		for(int i = 0; i < LongBeach.length; i++){
			System.out.println(LongBeach[i]);
		}
	}
	
/*	public double getLongitude(String specificPort){
		for(int i = 0; i <=3; i++){
			if(specificPort.equals();
	}*/
	
//}