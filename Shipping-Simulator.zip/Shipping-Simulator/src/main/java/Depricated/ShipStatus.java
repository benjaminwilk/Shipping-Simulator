package main.java.Depricated;

public class ShipStatus{
	


	/*public ShipStatus(Boat playerObject){
		Abstract.RotateOptions(MenuDisplays.GetShoreOptionMenu()); //"Check Weather Report", "Check Ship Status", "Refuel Ship", "Check Port Prices", "Go Back"
		System.out.println("Beet test");
		ParseShoreOptions(Abstract.ScannerInt(), playerObject);
	}
	
	public ShipStatus(Boat playerObject, boolean UpgradeOrFuel){
		if(UpgradeOrFuel == true){
	//		UpgradeShip(playerObject);
		} else {
	//		shipFuel(playerObject);
		}
	}

	//"Check Weather Report", "Check Ship Status", "Refuel Ship", "Check Port Prices", "Go Back"
	private void ParseShoreOptions(int userInput, Boat playerObject){

		if(userInput == 1){
			;
		}
		if(userInput == 2){
			UpgradeShip(playerObject);
		}
		if(userInput == 3){
			System.out.println("Beep boop");
			shipFuel(playerObject);
		}
		if(userInput == 4){
			new SeaWeather().FormattedWeatherAndTemperature(playerObject, 30);
		}
	}


	
	public void shipDamage(){
		
	}*/


	
}