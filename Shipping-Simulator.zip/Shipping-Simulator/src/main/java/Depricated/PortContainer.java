package main.java.Depricated;/*package src.main.java;

import src.main.java.Player.*;
import src.main.java.Abstract.*;

public class PortContainer{

	AvailablePorts[] allPorts = new AvailablePorts[3];
	String[] portTitles = {"long beach", "hong kong", "sydney"};

	public PortContainer(){
		this.allPorts[0] = new AvailablePorts("long beach");
		this.allPorts[1] = new AvailablePorts("hong kong");
		this.allPorts[2] = new AvailablePorts("sydney");
	}

}*/