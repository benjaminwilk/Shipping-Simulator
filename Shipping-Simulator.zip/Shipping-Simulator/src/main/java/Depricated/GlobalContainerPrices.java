package main.java.Depricated;/*package src.main.java;

import src.main.java.Player.*;
import java.util.ArrayList;

public class GlobalContainerPrices{

	public GlobalContainerPrices(){		
		DisplayPriceHeader();
		//ArrayList<PortContainerPrice> PortsAndContainers = CreatePortsAndPrices();
	//	displayPrices(PortsAndContainers);
	}

	public void DisplayPriceHeader(){
		System.out.println("Global Price List:");
	}*/
	
/*	public void displayPrices(ArrayList<PortContainerPrice> PortsAndContainers){
		for(int i = 0 ; i < PortsAndContainers.size(); i++){
			System.out.println(PortsAndContainers.get(i).GetShortName() + " -- $" + PortsAndContainers.get(i).GetContainerPrice() + " per container -- " + PortsAndContainers.get(i).GetContainerCount());
			//System.out.println(MenuDisplays.getAvailablePorts(i) + " -- $" + Abstract.getRandomValue(500, 20) + " per container");
		}
		Abstract.pressAnyKey();
	}*/
	
//}