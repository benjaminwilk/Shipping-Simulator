package src.main.java;

import src.main.java.Player.*;

public class PortChoice{
	private String currentPort;
	private String destinationPort;
	private int portDistance;

	public PortChoice(){
		this.currentPort = MenuDisplays.GetAvailablePorts(1);
	}

	public void iteration(Boat playerObject){
		int portChoice = 0;
//		do{
			System.out.println("Current Port: " + getCurrentPort());
			Abstract.RotateOptionsWithEscapement(MenuDisplays.GetAvailablePorts());
			System.out.print(": ");
			portChoice = setDestinationPort(Abstract.ScannerInt());
	//	}while(portChoice <= 3);
	//	changeCurrentAndDestination();
	}
	
	public String getCurrentPort(){
		return this.currentPort;
	}
	
	public String getDestinationPort(){
		return this.destinationPort;
	}

	private void setCurrentPort(int userValueChosenPort){
		this.currentPort = MenuDisplays.GetAvailablePorts(userValueChosenPort);
	}

	private void setCurrentPort(String userPortText){
		for(int i = 0; i < MenuDisplays.GetAvailablePortsSize(); i++){
			if(userPortText.contains(MenuDisplays.GetAvailablePorts(i))){
				this.currentPort = MenuDisplays.GetAvailablePorts(i);
			}
		}
	}

	public void changeCurrentAndDestination(){
		this.currentPort = this.destinationPort;
		this.destinationPort = null;
	}

	private int setDestinationPort(int userValueChosenPort){
		this.destinationPort = MenuDisplays.GetAvailablePorts(userValueChosenPort);
		return userValueChosenPort;
	}

	private int setDestinationPort(String userPortText){
		for(int i = 0; i < MenuDisplays.GetAvailablePortsSize(); i++){
			if(userPortText.contains(MenuDisplays.GetAvailablePorts(i))){
				this.destinationPort = MenuDisplays.GetAvailablePorts(i);
				return i;
			}
		}
		return 0;
	}

}
