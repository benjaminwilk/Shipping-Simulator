package src.main.java;

import src.main.java.Player.*;
import java.util.ArrayList;


public class PrimaryLoop{

	Boat playerObject;
	PortChoice portDecision;
	LoadUnloadContainers shoreContainers;
	Movement move;
	Weather UserWeather;
	AvailablePorts[] portLocations = new AvailablePorts[3];
	

	public PrimaryLoop(){
		this.UserWeather = new Weather();
		InitializeObjects();
		InitializePorts();
		IterativeFunction();
	}

	public void IterativeFunction(){
		this.portDecision = new PortChoice();
		this.shoreContainers = new LoadUnloadContainers(portLocations);
		this.move = new Movement();
		//this.LocationContainer = new PortContainer();
		
		while(true){
			this.shoreContainers.Iteration(this.playerObject);
			this.portDecision.iteration(this.playerObject);
			this.move.iteration(this.playerObject, portDecision);
		}	
	}
		
	public void InitializeObjects(){
		this.playerObject = new Boat("USS Enterprise", UpgradePath.getDefaultUserShip());
		//new Main().GeneratePortsAndCoordinates();
	//	playerObject.GetUserReadout();

	}
	
	public void InitializePorts(){
		portLocations[0] = new AvailablePorts("Long Beach");
		portLocations[1] = new AvailablePorts("Hong Kong");
		portLocations[2] = new AvailablePorts("Sydney");
	}
	
}